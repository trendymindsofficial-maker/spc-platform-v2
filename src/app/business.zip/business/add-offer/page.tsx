"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { auth, db } from "@/lib/firebase";

import {
  addDoc,
  collection,
  serverTimestamp,
} from "firebase/firestore";

import { v4 as uuid } from "uuid";

export default function AddOffer() {

  const router = useRouter();

  const [title, setTitle] = useState("");
  const [discount, setDiscount] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");

  const [imageFile, setImageFile] =
    useState<File | null>(null);

  const [preview, setPreview] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const saveOffer = async () => {

    if (
      !title ||
      !discount ||
      !description ||
      !category ||
      !imageFile
    ) {
      alert("Fill all fields");
      return;
    }

    const user = auth.currentUser;

    if (!user) {
      alert("Login Required");
      return;
    }

    try {

      setLoading(true);

      const data = new FormData();

      data.append("file", imageFile);

      data.append(
        "upload_preset",
        "spc_offers"
      );

      data.append(
        "public_id",
        uuid()
      );

      const upload = await fetch(
        "https://api.cloudinary.com/v1_1/vwyjcwb2/image/upload",
        {
          method: "POST",
          body: data,
        }
      );

      const uploaded =
        await upload.json();

      const image =
        uploaded.secure_url;

      await addDoc(
        collection(db, "offers"),
        {
          businessId: user.uid,
          title,
          discount,
          description,
          category,
          image,
          status: "active",
          createdAt:
            serverTimestamp(),
        }
      );

      alert("Offer Added");

      router.replace(
        "/business/dashboard"
      );

    } catch (e) {

      console.log(e);

      alert("Upload Failed");

    } finally {

      setLoading(false);

    }

  };

  return (

    <main className="min-h-screen bg-slate-100 p-6">

      <div className="mx-auto max-w-xl rounded-3xl bg-white p-8 shadow-xl">

        <div className="mb-8 flex items-center justify-between">

          <button
            onClick={() =>
              router.push("/business/dashboard")
            }
            className="rounded-xl bg-gray-200 px-4 py-2 font-semibold hover:bg-gray-300"
          >
            ← Dashboard
          </button>

          <h1 className="text-3xl font-bold">
            ➕ Add Offer
          </h1>

          <button
            onClick={() => router.back()}
            className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
          >
            ← Back
          </button>

        </div>

        <div className="space-y-4">

          <input
            placeholder="Offer Title"
            value={title}
            onChange={(e)=>setTitle(e.target.value)}
            className="w-full rounded-xl border p-3"
          />

          <input
            placeholder="Discount"
            value={discount}
            onChange={(e)=>setDiscount(e.target.value)}
            className="w-full rounded-xl border p-3"
          />

          <select
            value={category}
            onChange={(e)=>setCategory(e.target.value)}
            className="w-full rounded-xl border p-3"
          >

            <option value="">
              Select Category
            </option>

            <option>Restaurant</option>
            <option>Hospital</option>
            <option>Shopping</option>
            <option>Clothing</option>
            <option>Gym</option>
            <option>Education</option>
            <option>Electronics</option>
            <option>Salon</option>
            <option>Other</option>

          </select>

          <textarea
            placeholder="Offer Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="h-32 w-full rounded-xl border p-3"
          />
                    <div>

            <label className="mb-2 block font-semibold">
              Offer Image
            </label>

            <input
              type="file"
              accept="image/*"
              onChange={(e) => {

                if (!e.target.files?.length) return;

                const file = e.target.files[0];

                setImageFile(file);

                setPreview(
                  URL.createObjectURL(file)
                );

              }}
              className="w-full rounded-xl border p-3"
            />

          </div>

          {preview && (

            <img
              src={preview}
              alt="Preview"
              className="h-56 w-full rounded-xl object-cover"
            />

          )}

          <div className="flex gap-4">

            <button
              type="button"
              onClick={() =>
                router.push("/business/dashboard")
              }
              className="flex-1 rounded-xl border border-gray-300 bg-white py-4 text-lg font-semibold hover:bg-gray-100"
            >
              Cancel
            </button>

            <button
              onClick={saveOffer}
              disabled={loading}
              className="flex-1 rounded-xl bg-green-600 py-4 text-lg font-bold text-white hover:bg-green-700 disabled:opacity-50"
            >
              {loading
                ? "Uploading Offer..."
                : "Save Offer"}
            </button>

          </div>

        </div>

      </div>

    </main>

  );

}