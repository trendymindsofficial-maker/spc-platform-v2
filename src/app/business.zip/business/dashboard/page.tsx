"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import {
  collection,
  getDocs,
  query,
  where,
} from "firebase/firestore";

import {
  useEffect,
  useState,
} from "react";

export default function BusinessDashboard() {

  const router = useRouter();
  const [totalOffers, setTotalOffers] = useState(0);

const [totalScans, setTotalScans] = useState(0);

const [totalRedeemed, setTotalRedeemed] = useState(0);
const [businessName, setBusinessName] = useState("Business");

  const logout = async () => {
    await signOut(auth);
    router.replace("/business/login");
  };
 useEffect(() => {

  const unsubscribe = onAuthStateChanged(auth, async (user) => {

    if (!user) return;

    const businessSnap = await getDoc(
  doc(db, "businesses", user.uid)
);

if (businessSnap.exists()) {
  setBusinessName(
    businessSnap.data().businessName || "Business"
  );
}
    const offersQuery = query(
      collection(db, "offers"),
      where("businessId", "==", user.uid)
    );

    const offersSnap = await getDocs(offersQuery);
    setTotalOffers(offersSnap.size);

    const redeemQuery = query(
      collection(db, "redemptions"),
      where("businessId", "==", user.uid)
    );

    const redeemSnap = await getDocs(redeemQuery);

    setTotalScans(redeemSnap.size);
    setTotalRedeemed(redeemSnap.size);

  });

  return () => unsubscribe();

}, []);

  return (
    <main className="min-h-screen bg-slate-100 p-6">

      <div className="mx-auto max-w-5xl">

        <div className="mb-8 flex items-center justify-between">

          <div>
  <h1 className="text-4xl font-bold text-green-700">
    👋 Welcome, {businessName}
  </h1>

  <p className="mt-2 text-gray-600">
    Manage your offers, scan student QR codes and track redemptions.
  </p>
</div>
          <button
            onClick={logout}
            className="rounded-xl bg-red-600 px-5 py-3 font-bold text-white hover:bg-red-700"
          >
            Logout
          </button>

        </div>
       

        <div className="grid gap-6 md:grid-cols-2">
                  <Link
            href="/business/add-offer"
            className="rounded-2xl bg-white p-8 shadow-lg transition hover:scale-105"
          >
            <h2 className="mb-2 text-2xl font-bold text-green-700">
              ➕ Add Offer
            </h2>

            <p className="text-gray-600">
              Create new offers for students.
            </p>
          </Link>

          <Link
            href="/business/my-offers"
            className="rounded-2xl bg-white p-8 shadow-lg transition hover:scale-105"
          >
            <h2 className="mb-2 text-2xl font-bold text-blue-700">
              🎁 My Offers
            </h2>

            <p className="text-gray-600">
              View and manage all your offers.
            </p>
          </Link>

          <Link
            href="/business/scan"
            className="rounded-2xl bg-white p-8 shadow-lg transition hover:scale-105"
          >
            <h2 className="mb-2 text-2xl font-bold text-purple-700">
              📷 Scan Student QR
            </h2>

            <p className="text-gray-600">
              Scan student QR code to redeem offers.
            </p>
          </Link>

          <Link
            href="/business/history"
            className="rounded-2xl bg-white p-8 shadow-lg transition hover:scale-105"
          >
            <h2 className="mb-2 text-2xl font-bold text-orange-700">
              📊 Redeem History
            </h2>

            <p className="text-gray-600">
              View redeemed offers history.
            </p>
          </Link>
                  </div>

        <div className="mt-10 rounded-3xl bg-white p-6 shadow-lg">

          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">

            <div>

              <div className="rounded-3xl bg-white p-8 shadow-xl">

  

  <p className="mt-3 text-gray-600">

    Manage your offers, scan student QR codes, and track all redemptions from one dashboard.

  </p>

  <div className="mt-8 grid grid-cols-3 gap-4">

    <div className="rounded-2xl bg-green-50 p-5 text-center">

      <p className="text-sm text-gray-500">
        🎁 Total Offers
      </p>

      <h3 className="mt-2 text-3xl font-bold text-green-600">

        {totalOffers}

      </h3>

    </div>

    

    <div className="rounded-2xl bg-orange-50 p-5 text-center">

      <p className="text-sm text-gray-500">
        🎉 Redeemed
      </p>

      <h3 className="mt-2 text-3xl font-bold text-orange-600">

         {totalRedeemed}

      </h3>

    </div>

  </div>

</div>

              <p className="mt-2 text-gray-600">
                Manage offers, scan student QR codes, and track redemptions from one place.
              </p>

            </div>

            

          </div>

        </div>

      </div>

    </main>
  );
}
