"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import { db } from "@/lib/firebase";

import {
  doc,
  getDoc,
  updateDoc,
} from "firebase/firestore";

import { v4 as uuid } from "uuid";

export default function EditOffer() {

  const router = useRouter();

  const searchParams = useSearchParams();

  const offerId = searchParams.get("id");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState("");
  const [discount, setDiscount] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");

  const [oldImage, setOldImage] = useState("");
  const [preview, setPreview] = useState("");

  const [imageFile, setImageFile] =
    useState<File | null>(null);

  useEffect(() => {

    if (!offerId) {

      router.replace("/business/my-offers");

      return;

    }

    loadOffer();

  }, []);

  const loadOffer = async () => {

    try {

      const snap = await getDoc(
        doc(db, "offers", offerId!)
      );

      if (!snap.exists()) {

        alert("Offer Not Found");

        router.replace("/business/my-offers");

        return;

      }

      const data = snap.data();

      setTitle(data.title || "");

      setDiscount(data.discount || "");

      setCategory(data.category || "");

      setDescription(data.description || "");

      setOldImage(data.image || "");

      setPreview(data.image || "");

      setLoading(false);

    } catch (e) {

      console.log(e);

      alert("Failed to load offer");

    }

  };

  const updateOffer = async () => {

    if (
      !title ||
      !discount ||
      !category ||
      !description
    ) {

      alert("Fill all fields");

      return;

    }

    try {

      setSaving(true);

      let image = oldImage;
            if (imageFile) {

        const data = new FormData();

        data.append("file", imageFile);

        data.append(
          "upload_preset",
          "spc_offers"
        );

        data.append(
          "public_id",
          uuid()
        );

        const upload = await fetch(
          "https://api.cloudinary.com/v1_1/vwyjcwb2/image/upload",
          {
            method: "POST",
            body: data,
          }
        );

        const uploaded =
          await upload.json();

        image =
          uploaded.secure_url;

      }

      await updateDoc(
        doc(db, "offers", offerId!),
        {

          title,

          discount,

          category,

          description,

          image,

        }
      );

      alert("Offer Updated Successfully");

      router.replace(
        "/business/my-offers"
      );

    } catch (e) {

      console.log(e);

      alert("Update Failed");

    } finally {

      setSaving(false);

    }

  };

  if (loading) {

    return (

      <div className="flex min-h-screen items-center justify-center text-2xl font-bold">

        Loading...

      </div>

    );

  }

  return (

    <main className="min-h-screen bg-slate-100 p-6">

      <div className="mx-auto max-w-xl rounded-3xl bg-white p-8 shadow-xl">

        <div className="mb-8 flex items-center justify-between">

          <button
            onClick={() =>
              router.push("/business/dashboard")
            }
            className="rounded-xl bg-gray-200 px-4 py-2 font-semibold hover:bg-gray-300"
          >
            ← Dashboard
          </button>

          <h1 className="text-3xl font-bold">
            ✏️ Edit Offer
          </h1>

          <button
  onClick={() =>
    router.push("/business/my-offers")
  }
  className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
>
  ← My Offers
</button>
        </div>

        <div className="space-y-4">

          <input
            placeholder="Offer Title"
            value={title}
            onChange={(e)=>
              setTitle(e.target.value)
            }
            className="w-full rounded-xl border p-3"
          />

          <input
            placeholder="Discount"
            value={discount}
            onChange={(e)=>
              setDiscount(e.target.value)
            }
            className="w-full rounded-xl border p-3"
          />

          <select
            value={category}
            onChange={(e)=>
              setCategory(e.target.value)
            }
            className="w-full rounded-xl border p-3"
          >

            <option value="">Select Category</option>

            <option>Restaurant</option>
            <option>Hospital</option>
            <option>Shopping</option>
            <option>Clothing</option>
            <option>Gym</option>
            <option>Education</option>
            <option>Electronics</option>
            <option>Salon</option>
            <option>Other</option>

          </select>

          <textarea
            placeholder="Offer Description"
            value={description}
            onChange={(e)=>
              setDescription(e.target.value)
            }
            className="h-36 w-full rounded-xl border p-3"
          />

          <label className="font-semibold">
            Change Offer Image (Optional)
          </label>

          <input
            type="file"
            accept="image/*"
            className="w-full rounded-xl border p-3"
            onChange={(e)=>{

              if(!e.target.files?.length)
                return;

              const file =
                e.target.files[0];

              setImageFile(file);

              setPreview(
                URL.createObjectURL(file)
              );

            }}
          />

          {preview && (

            <img
              src={preview}
              alt="Preview"
              className="h-60 w-full rounded-xl object-cover"
            />

          )}
                    <div className="mt-6 flex gap-4">

            <button
              type="button"
              onClick={() =>
                router.push("/business/my-offers")
              }
              className="flex-1 rounded-xl border border-gray-300 bg-white py-4 text-lg font-bold hover:bg-gray-100"
            >
              Cancel
            </button>

            <button
              onClick={updateOffer}
              disabled={saving}
              className="flex-1 rounded-xl bg-green-600 py-4 text-lg font-bold text-white hover:bg-green-700 disabled:opacity-50"
            >
              {saving
                ? "Updating..."
                : "💾 Save Changes"}
            </button>

          </div>

        </div>

      </div>

    </main>

  );

}